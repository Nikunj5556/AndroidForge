# S3 Swift Upload (Android source project)

A personal Android S3 uploader starter based on the supplied S3 Home HTML. Defaults are bucket `marqueein` and region `ap-south-1`. No credentials from the uploaded HTML are included in this project.

## Features
- Direct S3 uploads using the AWS Android SDK (no presigned URLs).
- Multipart uploads for larger files, with a configurable transfer queue.
- Android document picker for multi-file upload and folder-tree upload.
- S3 prefix/folder browser, destination selection, and folder creation.
- Transfer progress and upload notifications.
- Credentials saved in Android EncryptedSharedPreferences on-device.

## Important security note
The uploaded HTML contains what look like AWS access credentials in client-side source. Treat them as exposed: deactivate/rotate that access key in IAM before using this app. Do not hard-code a long-lived secret into an APK; APKs can be unpacked. This app asks for credentials on-device and encrypts them at rest, but a dedicated least-privilege IAM identity is still required. Restrict it to only the required bucket and actions, and never use root credentials.

## Build
1. Install Android Studio (current stable) with Android SDK Platform 35 and JDK 17.
2. Open this `s3-uploader-android` folder in Android Studio and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK from `app/build/outputs/apk/debug/app-debug.apk` on your personal Android device.
5. Open the app, enter the rotated IAM access key, secret, bucket and region. Choose the S3 destination folder, then upload.

## Notes / limitations
- Background transfer uses the AWS Android SDK TransferUtility service. Android can still stop transfers after a force-stop, reboot, severe battery restrictions, or OEM task-killer behavior. Test screen-off uploads on the target phone and allow background activity for the app.
- Actual speed depends on network uplink, device, S3 region, file size and IAM/bucket configuration. The app exposes six concurrent transfer tasks and 16 MiB multipart settings; more concurrency is not always faster and can increase memory/network contention.
- Folder selection traverses Android's Storage Access Framework. Some cloud-backed document providers may not expose all files or stable access.
- The project source has not been compiled in this environment because Android SDK/Gradle build tools are not installed here. Build and test in Android Studio before relying on it for important uploads.
