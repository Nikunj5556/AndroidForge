package com.nikunj.s3uploader

import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.mobileconnectors.s3.transferutility.*
import com.amazonaws.regions.Region
import com.amazonaws.regions.Regions
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.ListObjectsV2Request
import com.amazonaws.services.s3.model.ObjectMetadata
import com.amazonaws.services.s3.model.PutObjectRequest
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var dest: TextView
    private lateinit var progress: ProgressBar
    private lateinit var s3: AmazonS3Client
    private lateinit var transfer: TransferUtility
    private val io = Executors.newSingleThreadExecutor()
    private var bucket = "marqueein"
    private var regionName = "ap-south-1"
    private var prefix = ""
    private val notificationId = 2001
    private val channelId = "s3_uploads"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = securePrefs()
        createNotificationChannel()
        buildUi()
        if (prefs.getString("access", "").isNullOrBlank() || prefs.getString("secret", "").isNullOrBlank()) {
            showCredentialsDialog()
        } else connectAndRefresh()
    }

    private fun securePrefs(): android.content.SharedPreferences {
        val master = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(this, "s3_private_settings", master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 18); setBackgroundColor(0xFF101525.toInt()) }
        val title = TextView(this).apply { text = "S3 Swift Upload"; textSize = 26f; setTextColor(0xFFF4F6FF.toInt()); setTypeface(null, 1) }
        root.addView(title)
        root.addView(TextView(this).apply { text = "Direct-to-S3 • Multipart transfers • Background queue"; textSize = 13f; setTextColor(0xFFAAB4D0.toInt()); setPadding(0, 4, 0, 18) })
        val bucketLine = EditText(this).apply { setSingleLine(); hint = "Bucket name"; setText(bucket); setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9BA6C2.toInt()); setPadding(12, 10, 12, 10); setBackgroundColor(0xFF202941.toInt()) }
        root.addView(bucketLine, lp())
        val regionLine = EditText(this).apply { setSingleLine(); hint = "AWS region"; setText(regionName); setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9BA6C2.toInt()); setPadding(12, 10, 12, 10); setBackgroundColor(0xFF202941.toInt()) }
        root.addView(regionLine, lp())
        dest = TextView(this).apply { text = "Destination: /"; textSize = 15f; setTextColor(0xFFE8ECFA.toInt()); setPadding(0, 16, 0, 10) }
        root.addView(dest)
        root.addView(button("Choose S3 folder") { bucket = bucketLine.text.toString().trim(); regionName = regionLine.text.toString().trim(); connectAndPickFolder() }, lp())
        root.addView(button("Upload files") { launchFilePicker() }, lp())
        root.addView(button("Upload a folder") { launchFolderPicker() }, lp())
        root.addView(button("Create folder here") { createFolder() }, lp())
        root.addView(button("AWS credentials / settings") { showCredentialsDialog() }, lp())
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0 }
        root.addView(progress, lp())
        status = TextView(this).apply { text = "Add AWS credentials to connect."; textSize = 14f; setTextColor(0xFFB9C4E2.toInt()); setPadding(0, 12, 0, 8) }
        root.addView(status, lp())
        root.addView(TextView(this).apply { text = "Tip: use a dedicated IAM user limited to this bucket. Do not reuse root credentials."; textSize = 12f; setTextColor(0xFF8E9AB9.toInt()); setPadding(0, 12, 0, 0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun lp(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }

    private fun showCredentialsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val access = EditText(this).apply { hint = "AWS access key ID"; setSingleLine(); setText(prefs.getString("access", "")) }
        val secret = EditText(this).apply { hint = "AWS secret access key"; setSingleLine(); inputType = 129; setText(prefs.getString("secret", "")) }
        val b = EditText(this).apply { hint = "Bucket"; setSingleLine(); setText(prefs.getString("bucket", "marqueein")) }
        val r = EditText(this).apply { hint = "Region (e.g. ap-south-1)"; setSingleLine(); setText(prefs.getString("region", "ap-south-1")) }
        box.addView(access); box.addView(secret); box.addView(b); box.addView(r)
        AlertDialog.Builder(this).setTitle("Connect to AWS S3")
            .setMessage("Credentials are stored encrypted on this device. Long-lived keys inside any APK can be extracted; use a dedicated least-privilege IAM key.")
            .setView(box).setNegativeButton("Cancel", null).setPositiveButton("Save & connect") { _, _ ->
                prefs.edit().putString("access", access.text.toString().trim()).putString("secret", secret.text.toString().trim())
                    .putString("bucket", b.text.toString().trim()).putString("region", r.text.toString().trim()).apply()
                bucket = b.text.toString().trim(); regionName = r.text.toString().trim(); prefix = ""; connectAndRefresh()
            }.show()
    }

    private fun connectAndRefresh() {
        bucket = prefs.getString("bucket", bucket) ?: bucket
        regionName = prefs.getString("region", regionName) ?: regionName
        val a = prefs.getString("access", "") ?: ""; val k = prefs.getString("secret", "") ?: ""
        if (a.isBlank() || k.isBlank()) { status.text = "Credentials required."; return }
        try {
            val creds = BasicAWSCredentials(a, k)
            s3 = AmazonS3Client(creds, Region.getRegion(regionFromName(regionName)))
            val transferConfig = TransferUtilityConfiguration().apply {
                setConcurrentServiceTasks(6)
                setMinimumUploadPartSize(16L * 1024 * 1024)
                setMultipartUploadThreshold(16L * 1024 * 1024)
            }
            transfer = TransferUtility.builder().context(applicationContext).s3Client(s3)
                .defaultBucket(bucket).transferUtilityConfiguration(transferConfig).build()
            dest.text = "Destination: /${prefix}"
            status.text = "Connected client ready • $bucket • $regionName"
        } catch (e: Exception) { status.text = "Connection setup failed: ${e.message}" }
    }

    private fun regionFromName(name: String): Regions = try { Regions.fromName(name) } catch (_: Exception) { Regions.AP_SOUTH_1 }

    private fun connectAndPickFolder() {
        connectAndRefresh()
        io.execute {
            try {
                s3.listObjectsV2(ListObjectsV2Request().withBucketName(bucket).withPrefix("").withMaxKeys(1))
                runOnUiThread { pickFolderAt("") }
            } catch (e: Exception) { runOnUiThread { status.text = "Could not access bucket: ${e.message}" } }
        }
    }

    private fun pickFolderAt(start: String) {
        io.execute {
            try {
                val req = ListObjectsV2Request().withBucketName(bucket).withPrefix(start).withDelimiter("/").withMaxKeys(1000)
                val result = s3.listObjectsV2(req)
                val folders = result.commonPrefixes.sorted()
                runOnUiThread {
                    val choices = mutableListOf("✓ Use this folder: /${start.ifEmpty { "" }}")
                    if (start.isNotEmpty()) choices.add("⬅ .. (parent folder)")
                    choices.addAll(folders.map { "📁 ${it.removePrefix(start).trimEnd('/')}" })
                    AlertDialog.Builder(this).setTitle("Choose destination\n/${start}").setItems(choices.toTypedArray()) { _, which ->
                        val selected = choices[which]
                        when {
                            selected.startsWith("✓") -> { prefix = start; dest.text = "Destination: /${prefix}"; status.text = "Destination selected. Uploads will go here." }
                            selected.startsWith("⬅") -> pickFolderAt(start.trimEnd('/').substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" })
                            else -> { val folder = selected.removePrefix("📁 "); pickFolderAt(start + folder + "/") }
                        }
                    }.setNegativeButton("Cancel", null).show()
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Folder listing failed: ${e.message}" } }
        }
    }

    private val filePicker = registerForActivityResultCompat(false)
    private val folderPicker = registerForActivityResultCompat(true)

    // Uses the platform document picker; folder uploads preserve relative paths.
    private fun registerForActivityResultCompat(folder: Boolean): androidx.activity.result.ActivityResultLauncher<Intent> =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != RESULT_OK) return@registerForActivityResult
            val data = result.data ?: return@registerForActivityResult
            if (folder) {
                val uri = data.data ?: return@registerForActivityResult
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                uploadTree(uri, "")
            } else {
                val clip = data.clipData
                val uris = if (clip != null) (0 until clip.itemCount).map { clip.getItemAt(it).uri } else listOfNotNull(data.data)
                uris.forEach { uploadUri(it, queryName(it)) }
            }
        }

    private fun launchFilePicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        filePicker.launch(i)
    }
    private fun launchFolderPicker() { folderPicker.launch(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)) }

    private fun queryName(uri: Uri): String {
        var name = "upload-${System.currentTimeMillis()}"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) ?: name }
        return name
    }

    private fun uploadUri(uri: Uri, name: String) {
        try {
            val key = prefix + name.substringAfterLast('/').replace("\\", "_")
            val job = transfer.upload(bucket, key, uri)
            status.text = "Queued: $key"
            job.setTransferListener(object : TransferListener {
                override fun onStateChanged(id: Int, state: TransferState) {
                    runOnUiThread { status.text = "$key • ${state.name}"; if (state == TransferState.COMPLETED) progress.progress = 100 }
                    updateNotification("$key • ${state.name}", if (state == TransferState.COMPLETED) 100 else 0)
                }
                override fun onProgressChanged(id: Int, current: Long, total: Long) {
                    val pct = if (total > 0) (current * 100 / total).toInt() else 0
                    runOnUiThread { progress.progress = pct; status.text = "$key • $pct% • ${formatBytes(current)} / ${formatBytes(total)}" }
                    updateNotification("Uploading $key", pct)
                }
                override fun onError(id: Int, ex: Exception) { runOnUiThread { status.text = "Upload failed: ${ex.message}" }; updateNotification("Upload failed: $key", 0) }
            })
        } catch (e: Exception) { status.text = "Could not queue upload: ${e.message}" }
    }

    private fun uploadTree(tree: Uri, relative: String) {
        val children = contentResolver.query(android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree,
            android.provider.DocumentsContract.getTreeDocumentId(tree)), arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME, android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)
        if (children == null) { status.text = "Could not read selected folder."; return }
        children.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0); val name = c.getString(1) ?: "file"; val mime = c.getString(2)
                val child = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id)
                if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) uploadTreeChild(tree, child, relative + name + "/")
                else uploadUri(child, relative + name)
            }
        }
    }

    private fun uploadTreeChild(tree: Uri, folder: Uri, relative: String) {
        val id = android.provider.DocumentsContract.getDocumentId(folder)
        val childrenUri = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
        val c = contentResolver.query(childrenUri, arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME, android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null) ?: return
        c.use { cur -> while (cur.moveToNext()) {
            val childId = cur.getString(0); val name = cur.getString(1) ?: "file"; val mime = cur.getString(2)
            val child = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, childId)
            if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) uploadTreeChild(tree, child, relative + name + "/") else uploadUri(child, relative + name)
        } }
    }

    private fun createFolder() {
        val input = EditText(this).apply { hint = "Folder name" }
        AlertDialog.Builder(this).setTitle("Create S3 folder").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Create") { _, _ ->
            val name = input.text.toString().trim().trim('/')
            if (name.isBlank() || name.contains("..")) { status.text = "Enter a valid folder name."; return@setPositiveButton }
            io.execute {
                try {
                    val key = prefix + name + "/"
                    val meta = ObjectMetadata().apply { contentLength = 0 }
                    s3.putObject(PutObjectRequest(bucket, key, ByteArrayInputStream(ByteArray(0)), meta))
                    runOnUiThread { status.text = "Created /$key" }
                } catch (e: Exception) { runOnUiThread { status.text = "Folder creation failed: ${e.message}" } }
            }
        }.show()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "S3 uploads", NotificationManager.IMPORTANCE_LOW))
    }
    private fun updateNotification(text: String, pct: Int) {
        val n = NotificationCompat.Builder(this, channelId).setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("S3 Swift Upload").setContentText(text).setOnlyAlertOnce(true).setOngoing(pct in 1..99)
            .setProgress(100, pct.coerceIn(0, 100), false).build()
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notificationId, n)
    }
    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB"); var n = bytes.toDouble(); var i = -1
        do { n /= 1024; i++ } while (n >= 1024 && i < units.lastIndex)
        return String.format(java.util.Locale.US, "%.1f %s", n, units[i])
    }
}
